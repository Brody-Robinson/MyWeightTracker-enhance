package com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Adapters;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Models.WeightEntry;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.R;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.DBHelper;

import java.util.Calendar;
import java.util.List;

public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.ViewHolder> {
    private Context context;
    private List<WeightEntry> weightEntryList;
    DBHelper dbHelper;
    public WeightEntryAdapter(Context context, List<WeightEntry> weightEntryList,DBHelper dbHelper) {
        this.context = context;
        this.weightEntryList = weightEntryList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public WeightEntryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_recyclerview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightEntryAdapter.ViewHolder holder, int position) {
        WeightEntry weightEntry = weightEntryList.get(position);
        holder.tvDate.setText("Date: " + weightEntry.getDate());
        holder.tvWeight.setText("Weight: " + weightEntry.getWeight() + " lbs");
        holder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(dbHelper.deleteWeightEntry(weightEntry.getId())) {
                    weightEntryList.remove(position);
                    notifyItemRemoved(position);
                    Toast.makeText(context, "Entry deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to delete entry", Toast.LENGTH_SHORT).show();
                }
            }
        });
        holder.imgEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showUpdateWeightEntryDialog(position);
            }
        });
    }
    private void showUpdateWeightEntryDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_addnewentry, null);
        builder.setView(dialogView);

        final EditText etDate = dialogView.findViewById(R.id.etDate);
        final EditText etWeight = dialogView.findViewById(R.id.etWeight);
        Button btnSave = dialogView.findViewById(R.id.btnSave);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        etDate.setText(weightEntryList.get(position).getDate());
        etWeight.setText(String.valueOf(weightEntryList.get(position).getWeight()));

        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                                String selectedDate = (monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
                                etDate.setText(selectedDate);
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = etDate.getText().toString();
                String weight = etWeight.getText().toString();
                if (date.isEmpty() || weight.isEmpty()) {
                    Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (dbHelper.updateWeightEntry(weightEntryList.get(position).getId(), date,
                            Float.parseFloat(weight))) {
                        weightEntryList.get(position).setWeight(Float.parseFloat(weight));
                        weightEntryList.get(position).setDate(date);
                        notifyDataSetChanged();
                        Toast.makeText(context, "Weight entry updated successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Failed to update entry", Toast.LENGTH_SHORT).show();
                    }
                    dialog.dismiss();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    @Override
    public int getItemCount() {
        return weightEntryList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvDate, tvWeight;
        public ImageView imgPreview, imgDelete, imgEdit;

        public ViewHolder(View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            imgPreview = itemView.findViewById(R.id.imgPreview);
            imgDelete = itemView.findViewById(R.id.imgDelete);
            imgEdit = itemView.findViewById(R.id.imgEdit);
        }
    }
}
