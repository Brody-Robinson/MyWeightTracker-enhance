package com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities;

import android.content.Context;
import android.content.SharedPreferences;

public class UserSessionManager {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private Context context;

    private static final String PREF_NAME = "UserSessionPref";

    private static final String IS_LOGIN = "IsLoggedIn";
    private static final String KEY_FULL_NAME = "FullName";
    private static final String KEY_MAIL = "Mail";
    private static final String KEY_NOTIFY = "Notify";
    private static final String KEY_TARGET_WEIGHT = "TargetWeight";

    public UserSessionManager(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void createUserSession(String fullName, float targetWeight,String mail) {
        editor.putBoolean(IS_LOGIN, true);
        editor.putString(KEY_FULL_NAME, fullName);
        editor.putString(KEY_MAIL, mail);
        editor.putFloat(KEY_TARGET_WEIGHT, targetWeight);
        editor.commit();
    }
    public void setNotify(boolean b){
        editor.putBoolean(KEY_NOTIFY,b);
        editor.commit();
    }
    public boolean getNotify(){
        return sharedPreferences.getBoolean(KEY_NOTIFY,false);
    }

    public String getFullName() {
        return sharedPreferences.getString(KEY_FULL_NAME, null);
    }
    public String getMail() {
        return sharedPreferences.getString(KEY_MAIL, null);
    }

    public float getTargetWeight() {
        return sharedPreferences.getFloat(KEY_TARGET_WEIGHT, -1);
    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(IS_LOGIN, false);
    }

    public void logoutUser() {
        editor.clear();
        editor.commit();
    }
}
