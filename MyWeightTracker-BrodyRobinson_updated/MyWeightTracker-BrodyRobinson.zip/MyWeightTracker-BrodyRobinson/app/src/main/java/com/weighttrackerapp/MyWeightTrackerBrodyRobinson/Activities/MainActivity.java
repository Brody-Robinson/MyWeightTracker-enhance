package com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Adapters.WeightEntryAdapter;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Models.WeightEntry;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.R;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.DBHelper;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.UserSessionManager;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.databinding.ActivityMainBinding;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    UserSessionManager userSessionManager;
    DBHelper dbHelper;
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 67) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                userSessionManager.setNotify(true);
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void requestNotificationPermission() {
        new AlertDialog.Builder(this)
                .setTitle("Notification Permission")
                .setMessage("Would you like to receive a notiication when reaching your goal weight?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 67);}else {
                            userSessionManager.setNotify(true);
                        }
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userSessionManager.setNotify(false);
                        dialogInterface.dismiss();
                    }
                })
                .create()
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        userSessionManager=new UserSessionManager(this);
        dbHelper=new DBHelper(this);
        if (!userSessionManager.getNotify()){
            requestNotificationPermission();}


        List<WeightEntry> entries = dbHelper.getAllWeightEntries();
        WeightEntryAdapter adapter = new WeightEntryAdapter(this, entries,dbHelper);

        binding.recyclerView.setAdapter(adapter);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_change_target_weight) {
            showChangeTargetWeightDialog(dbHelper.getTargetWeightByEmail(userSessionManager.getMail()));
           return true;
        }
        if (id == R.id.action_add_new_entry) {
            showWeightEntryDialog();
            return true;
        }
        if (id == R.id.action_signout) {
            userSessionManager.logoutUser();
            finish();
            startActivity(new Intent(MainActivity.this,LoginActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void showChangeTargetWeightDialog(float currentTargetWeight) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Target Weight");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(currentTargetWeight));
        builder.setView(input);

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String weightStr = input.getText().toString();
                if (!weightStr.isEmpty()) {
                    float newTargetWeight = Float.parseFloat(weightStr);
                    if (dbHelper.updateUserTargetWeight(userSessionManager.getMail(),
                            newTargetWeight)) {
                        Toast.makeText(MainActivity.this, "Target weight updated successfully.",
                                Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(MainActivity.this, "Failed to update target weight.", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(getApplicationContext(), "Please enter a valid weight", Toast.LENGTH_SHORT).show();
                }
            }
        });


        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void showWeightEntryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_addnewentry, null);
        builder.setView(dialogView);

        final EditText etDate = dialogView.findViewById(R.id.etDate);
        final EditText etWeight = dialogView.findViewById(R.id.etWeight);
        Button btnSave = dialogView.findViewById(R.id.btnSave);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        dialogView.setBackground(getResources().getDrawable(R.drawable.bg_dialog));

        AlertDialog dialog = builder.create();

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Tarih seçici dialog'unu göster
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                // Tarih seçildikten sonra EditText'e tarihi Ay/Gün/Yıl formatında set et
                                String selectedDate = (monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
                                etDate.setText(selectedDate);
                            }
                        }, year, month, day);
                datePickerDialog.show();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = etDate.getText().toString();
                String weight = etWeight.getText().toString();
                if (date.isEmpty() || weight.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {

                    dbHelper.addWeightEntry(date, Float.parseFloat(weight));
                    if (!dbHelper.addWeightEntry(date, Float.parseFloat(weight))) {
                        Toast.makeText(MainActivity.this, "Weight entry added successfully",
                                Toast.LENGTH_SHORT).show();
                        WeightEntryAdapter adapter = new WeightEntryAdapter(MainActivity.this,
                                dbHelper.getAllWeightEntries(),
                                dbHelper);

                        binding.recyclerView.setAdapter(adapter);
                        binding.recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                        checkWeight(weight);
                    } else {
                        Toast.makeText(MainActivity.this, "Entry for this date already exists",
                                Toast.LENGTH_SHORT).show();
                    }
                    dialog.dismiss();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
    public void checkWeight(String weight){
        if (Float.parseFloat(weight)==dbHelper.getTargetWeightByEmail(userSessionManager.getMail())){
            sendCongratulationsNotification(userSessionManager.getFullName(),
                    Float.parseFloat(weight));
        }
    }
    private void sendCongratulationsNotification(String userName, float weight) {
        String CHANNEL_ID = "target_weight_channel";
        int notificationId = (int) System.currentTimeMillis();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Target Weight Channel";
            String description = "Channel for Target Weight Notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher_round) // Uygun bir simge seçin
                .setContentTitle("Congratulations, " + userName + "!")
                .setContentText("You've reached your target weight of " + weight + " lbs.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(notificationId, builder.build());
    }

}