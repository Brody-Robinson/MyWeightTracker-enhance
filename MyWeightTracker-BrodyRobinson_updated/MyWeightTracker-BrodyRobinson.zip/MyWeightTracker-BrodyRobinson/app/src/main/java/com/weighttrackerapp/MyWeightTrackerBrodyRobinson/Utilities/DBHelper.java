package com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Models.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 1;

    private static final String CREATE_TABLE_USER = "CREATE TABLE user (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, password TEXT, fullName TEXT, targetWeight REAL)";
    private static final String CREATE_TABLE_WEIGHT_ENTRY = "CREATE TABLE weightEntry (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, weight REAL)";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_WEIGHT_ENTRY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE email = ? AND password = ?", new String[]{email, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }
    public String getFullNameByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String fullName = null;

        Cursor cursor = db.rawQuery("SELECT fullName FROM user WHERE email = ?", new String[]{email});

        if (cursor.moveToFirst()) {
            fullName = cursor.getString(cursor.getColumnIndex("fullName"));
        }

        cursor.close();
        db.close();

        return fullName;
    }
    public float getTargetWeightByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        float targetWeight = -1;

        Cursor cursor = db.rawQuery("SELECT targetWeight FROM user WHERE email = ?", new String[]{email});

        if (cursor.moveToFirst()) {
            targetWeight = cursor.getFloat(cursor.getColumnIndex("targetWeight"));
        }

        cursor.close();
        db.close();

        return targetWeight;
    }

    public boolean registerUser(String email, String password, String fullName, float targetWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE email = ?", new String[]{email});
        if (cursor.getCount() > 0) {
            cursor.close();
            return false;
        } else {

            ContentValues values = new ContentValues();
            values.put("email", email);
            values.put("password", password);
            values.put("fullName", fullName);
            values.put("targetWeight", targetWeight);

            long result = db.insert("user", null, values);
            cursor.close();
            db.close();
            return result != -1;
        }
    }

    public boolean addWeightEntry(String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM weightEntry WHERE date = ?", new String[]{date});
        if (cursor.getCount() > 0) {
            cursor.close();
            return false;
        } else {
            ContentValues values = new ContentValues();
            values.put("date", date);
            values.put("weight", weight);

            long result = db.insert("weightEntry", null, values);
            cursor.close();
            db.close();
            return result != -1;
        }
    }

    public List<WeightEntry> getAllWeightEntries() {
        List<WeightEntry> weightEntries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT * FROM weightEntry";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String date = cursor.getString(cursor.getColumnIndex("date"));
                float weight = cursor.getFloat(cursor.getColumnIndex("weight"));

                WeightEntry weightEntry = new WeightEntry(id, date, weight);
                weightEntries.add(weightEntry);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return weightEntries;
    }
    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("weightEntry", "id = ?", new String[]{String.valueOf(id)}) > 0;
    }
    public boolean updateWeightEntry(int id, String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("weight", weight);

        int update = db.update("weightEntry", values, "id = ?", new String[]{String.valueOf(id)});
        return update > 0;
    }
    public boolean updateUserTargetWeight(String email, float newTargetWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("targetWeight", newTargetWeight);

        int updateCount = db.update("user", values, "email = ?", new String[]{email});

        db.close();

        return updateCount > 0;
    }


}
