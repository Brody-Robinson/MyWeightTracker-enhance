package com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.DBHelper;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.UserSessionManager;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.databinding.ActivityRegisterBinding;


public class RegisterActivity extends AppCompatActivity {
    ActivityRegisterBinding binding;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dbHelper=new DBHelper(this);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signUp();
            }
        });
    }

    private void signUp() {
        String mail=binding.etMail.getText().toString();
        String password=binding.etPassword.getText().toString();
        String fullname=binding.etFullName.getText().toString();
        String weight=binding.etWeight.getText().toString();

        if (mail.isEmpty()|password.isEmpty()|fullname.isEmpty()|weight.isEmpty()){
            Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show();
       return;
        }
        if (dbHelper.registerUser(mail,password,fullname,Float.parseFloat(weight))){
            UserSessionManager userSessionManager=new UserSessionManager(this);
            userSessionManager.createUserSession(fullname,
                    Float.parseFloat(weight),mail);
            startActivity(new Intent(RegisterActivity.this,MainActivity.class));
        }else {
            Toast.makeText(this, "An error occurred, please try again", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
