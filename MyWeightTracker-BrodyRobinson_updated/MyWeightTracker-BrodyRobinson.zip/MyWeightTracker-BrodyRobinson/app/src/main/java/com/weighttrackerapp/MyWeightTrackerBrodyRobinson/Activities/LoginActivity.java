package com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.R;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.DBHelper;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.Utilities.UserSessionManager;
import com.weighttrackerapp.MyWeightTrackerBrodyRobinson.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {
    ActivityLoginBinding binding;
    DBHelper dbHelper;
    UserSessionManager userSessionManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userSessionManager=new UserSessionManager(this);
        if (userSessionManager.isLoggedIn()){
            finish();
            startActivity(new Intent(LoginActivity.this,MainActivity.class));
        }
        binding=ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dbHelper=new DBHelper(this);
        binding.btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
            }
        });
        
       binding.btnSignin.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               signin();
           }
       });
    }

    private void signin() {
        String mail=binding.etMail.getText().toString();
        String password=binding.etPassword.getText().toString();
        
        if (mail.isEmpty()|password.isEmpty()){
            Toast.makeText(this, "Please complete login information", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dbHelper.checkUser(mail,password)){

            userSessionManager.createUserSession(dbHelper.getFullNameByEmail(mail),
                    dbHelper.getTargetWeightByEmail(mail),mail);
            finish();
            startActivity(new Intent(LoginActivity.this,MainActivity.class));

        }else {
            Toast.makeText(this, "Username or password is incorrect", Toast.LENGTH_SHORT).show();
        }
    }
}